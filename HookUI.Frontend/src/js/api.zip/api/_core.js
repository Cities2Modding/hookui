/**
 * Core HookUI system for loading plugins and routing events.
 */
class HookUI {
    /**
     * Log a HookUI message
     * @param {string} message - The message
     */
    static log(message) {
        console.log(`[HookUI] ${message}`);
    }

    /**
     * Log a HookUI warning message
     * @param {string} message - The message
     */
    static warn(message) {
        console.warn(`[HookUI] ${message}`);
    }

    /**
     * Load the HookUI system.
     */
    static load() {
        HookUIEventSystem.load();
    }

    /**
     * Unload the HookUI system.
     */
    static unload() {
        HookUIEventSystem.unload();
    }

    /**
     * Get a plugin by id
     * @param {string} id - The ID of the plugin
     * @return {HookUIPlugin} A single HookUIPlugin instance
     */
    static getPlugin(id) {
        return HookUIPluginSystem.getPlugin(id);
    }

    /**
     * Get plugins, optionally filter by type
     * @param {string|null} type - Filter the plugins by a type specified in PluginType
     * @return {Array<HookUIPlugin>} Array of plugins, possibly filtered by type
     */
    static getPlugins(type = null) {
        return HookUIPluginSystem.getPlugins(type);
    }

    /**
     * Registers a plugin with the given configuration
     * @param {HookUIPlugin} plugin - Configuration object for the plugin
     */
    static register(config) {
        HookUIPluginSystem.register(config);
    }

    /**
     * Unregisters a plugin
     * @param {string} id - The ID for the plugin
     */
    static unregister(id) {
        HookUIPluginSystem.unregister(id);
    }

    /**
     * Trigger an event type
     * @param {string} eventType - The event type to trigger
     * @param {object} payload - The payload for the event
     */
    static trigger(eventType, payload) {
        HookUIEventSystem.dispatchEvent(eventType, payload);
    }

    /**
     * Toggles the visibility of the plugin with the given ID
     * @param {string} id - The ID of the plugin to toggle
     */
    static toggle(id) {
        this.trigger("toggle_visibility", { id });
    }

    /**
     * Play a UI sound effect
     * @param {string} sound - The name of the sound to use
     */
    static playSound(sound = "select-item") {
        engine.trigger("audio.playSound", sound, 1);
    }

    /**
     * Play a panel open/close sound effect
     * @param {boolean} isOpen - If true plays the open sound, otherwise close sound
     */
    static playPanelSound(isOpen) {
        HookUI.playSound(isOpen ? "open-panel" : "close-panel");
    }

    /**
     * Play a menu open/close sound effect
     * @param {boolean} isOpen - If true plays the open sound, otherwise close sound
     */
    static playMenuSound(isOpen) {
        HookUI.playSound(isOpen ? "open-menu" : "close-menu");
    }

    /**
     * Play the UI hover sound effect
     */
    static playHoverSound() {
        HookUI.playSound("hover-item");
    }
}

// Run
HookUI.load();

// Legacy stuff
window._$hookui = {}

window._$hookui.__registeredPanels = {}

// registerPanel works with two different types of panels, for legacy reasons
// You should pass in .body normally in order to set what elements inside of the
// $Panel component should be
// Correct Syntax:
// window._$hookui.registerPanel({
//     id: "example.city-monitor",
//     name: "City Monitor",
//     icon: "Media/Game/Icons/BuildingLevel.svg",
//     body: <div>This is inside the $Panel</div>,
// })
// Initially though, .component was accepted and should in that case be the $Panel
// itself. It wasn't correct though, as the $Panel should be managed by HookUI
// instead of by the mod authors.
// Legacy Syntax (Don't use this unless you must):
// window._$hookui.registerPanel({
//     id: "example.city-monitor",
//     name: "City Monitor",
//     icon: "Media/Game/Icons/BuildingLevel.svg",
//     component: <$Panel title="City Monitor">This is my very own panel</$Panel>,
// })

/**
 * Register a plugin (Retained for legacy compatibility)
 */
window._$hookui.registerPanel = ({ id, name, icon, component, body, panel_style }) => {
    HookUI.register({ id, name, icon, component, body, style: panel_style });
}

window._$hookui.toggleVisibility = (id) => {
    const event = new CustomEvent('hookui', { detail: { type: "toggle_visibility", id: id } });
    window.dispatchEvent(event);
}