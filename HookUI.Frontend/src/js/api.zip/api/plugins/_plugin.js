class HookUIPlugin {
    id;
    type;
    name;
    icon;
    description;
    component;
    style;
}